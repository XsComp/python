strOne = "Hello"
strTwo = " world"
strThree = ""
complex = ["aa","bb","cc","dd","ee"]


print(strThree)
strThree = strOne + strTwo
print(strThree)
