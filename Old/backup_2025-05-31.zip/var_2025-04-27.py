#! python3

# Start en variabel med en integer verdi
var = 8
print(var)

# Tildel en ny verdi, og vis frem den lagrede verdien.
var = 3.142
print(var)

# Igjen endrer vi variabelen. Nå vil vi at den skal inneholde en lang verdi.
var = 'Vi lærer Python, litt om gangen'
print(var)

#Til slutt tildeler vi en boolean verdi til variabelen
var = True
print(var)