#test.py

print('Hvor gammel er du min venn?')
navn=input()
print('Wooooow... that\'s ooooold maaaan,',navn, ', holy shit!!!')
