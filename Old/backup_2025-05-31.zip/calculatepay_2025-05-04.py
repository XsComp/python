def hourly_pay(hours, rate):
    return hours * rate

def monthly_pay(hourly, weeks=4):
    return hourly * weeks * 40