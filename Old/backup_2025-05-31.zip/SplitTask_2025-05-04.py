#SplitTask.py

# Vi lager en lang streng
#strMelding = "what,is,not,good,I,will,be,you,ok,Noroff,student,Python,a,awesome,pretty,knew,who,would,programmer"

# Vi splitter strengen, og bruker komma som separator
#ord = strMelding.split(",")

# Indeksene vi ønsker å hente
#indekser = [16,15,4,17,6,12,11,18]

# Vi skriver de hentede indeksene til skjerm.
#for i in indekser:
#    print(ord[i])

# Vi lager en streng
#strLinjeUnder = 'Vi må sette en strek under hele denne linjen'

# Vi skriver ut strengen
#print(strLinjeUnder)

# Vi skriver ut strengen igjen, denne gangen med linje under.
#print("-" * len(strLinjeUnder))

# Igjen lager vi en streng...
#tekst = "Vi endrer separator"

# Vi erstatter mellomrom med forskjellige separatorer.
#semikolon_versjon = tekst.replace(" ", ";")
#komma_versjon = tekst.replace(" ", ",")
#pipe_versjon = tekst.replace(" ", "|")

# og skriver dem til skjerm
#print("Semikolon :", semikolon_versjon)
#print("Komma     :", komma_versjon)
#print("Pipe      :", pipe_versjon)

# Vi spør bruker om input
#bruker_input = input("Skriv noe (med 'bra' eller 'dårlig'): ")

# Erstatt nøkkelord
#modifisert = bruker_input.replace("bra", "supert").replace("dårlig", "perfekt")

# Og vi skriver det til skjerm
#print("Modifisert:", modifisert)

#import this


      