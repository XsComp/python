# plussen.py

class Ansatt:
    telling = 0   # Telling av ansatte, initialisert til 0