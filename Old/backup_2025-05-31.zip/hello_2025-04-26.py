print("Hello Andreas! Coffee is ready!")
