#editor.py
 
# Aktivitet: Markerer ett ord med anførselstegn basert på indeks

# # Ber brukeren skrive inn en streng
# streng = input('Skriv inn en streng (den trenger ikke være kjempe streng): ')

# # Splitter strengen til en liste med ord
# ordliste = streng.split()

# # Viser lengden på strengen
# print(f'\nLengde på strengen: {len(streng)} tegn')

# # Viser antall ord i lista og spør brukeren om indeks
# print(f'Antall ord i strengen: {len(ordliste)}')
# indeks = int(input('Hvilket indeksnummer vil du sette i anførselstegn? (0-basert): '))

# # Legger anførselstegn rundt ordet på gitt indeks
# if 0 <= indeks < len(ordliste):
#     ordliste[indeks] = f'"{ordliste[indeks]}"'
#     redigert_streng = ' '.join(ordliste)
#     # print("\nRedigert streng:")
#     # print(redigert_streng)
# else:
#     print("Ugyldig indeks!")

# Skriv inn en streng (den trenger ikke være kjempe streng): Så den kan være litt slapp på ting? Det er ikke feil syns jeg... :P

# Lengde på strengen: 67 tegn
# Antall ord i strengen: 15
# Hvilket indeksnummer vil du sette i anførselstegn? (0-basert): 5

# Redigert streng:
# Så den kan være litt "slapp" på ting? Det er ikke feil syns jeg... :P