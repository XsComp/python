streng1 = "Jeg vil teste IDE-en " 
streng2 = "for å bli kjent med IDE og Python "
streng3 = "for å se om dette hjelper meg med å bli flink "
streng4 = "eller den beste til å programmere!"

print ("Hva vil du ha ut av dette kurset?\n\n")
nyStreng = streng1[0:8] + streng2[6:10] + streng4[6:33] + streng2[26:33] + streng4[33]
print("-"*50)
print(nyStreng)
print("-"*50)